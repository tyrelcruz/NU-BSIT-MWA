

package com.mycompany.movable;

public interface Movable {
    void moveUp();
    void moveDown();

    public String getSpeed();
}
