
package com.mycompany.movable;

public class Car implements Movable {
    private int speed;

    public void moveUp() {
        speed += 10;
    }

    public void moveDown() {
        speed -= 10;
    }

    public String getSpeed() {
        return Integer.toString(speed);
    }
}
