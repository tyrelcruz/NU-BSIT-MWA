
package com.mycompany.movable;

public class Bicycle implements Movable {
    private int speed;

    @Override
    public void moveUp() {
        speed += 10;
    }

    @Override
    public void moveDown() {
        speed -= 10;
        if (speed < 0) {
            speed = 0;
        }
    }

    @Override
    public String getSpeed() {
        return Integer.toString(speed);
    }
}

