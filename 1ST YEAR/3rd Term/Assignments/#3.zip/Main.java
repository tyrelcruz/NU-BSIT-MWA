
package com.mycompany.movable;

import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Movable[] objects = new Movable[2];
        objects[0] = new Car();
        objects[1] = new Bicycle();

        for (int i = 0; i < 2; i++) {
            for (Movable object : objects) {
                object.moveUp();
                if (object instanceof Car) {
                    System.out.println("Car speed: " + object.getSpeed());
                } else if (object instanceof Bicycle) {
                    System.out.println("Bicycle speed: " + object.getSpeed());
                }
            }
        }

        for (Movable object : objects) {
            object.moveDown();
            if (object instanceof Car) {
                System.out.println("Car speed: " + object.getSpeed());
            } else if (object instanceof Bicycle) {
                System.out.println("Bicycle speed: " + object.getSpeed());
            }
        }
    }
}



