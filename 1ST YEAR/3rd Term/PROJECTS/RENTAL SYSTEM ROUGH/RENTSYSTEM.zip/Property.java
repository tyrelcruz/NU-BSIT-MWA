/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.rentsystem;

/**
 *
 * @author Tyrel
 */
import java.io.*;
import java.util.*;

class Property {
    private int id;
    private String name;
    private String location;
    private boolean available;
    private double price;

    public Property(String name, String location, double price) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.available = available;
        this.price = price;
    }

    // Getters and setters

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public boolean isAvailable() {
        return available;
    }

    public double getPrice() {
        return price;
    }
}