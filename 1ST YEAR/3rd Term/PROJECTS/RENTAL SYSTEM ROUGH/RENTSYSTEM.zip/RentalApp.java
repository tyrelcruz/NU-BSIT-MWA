/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.rentsystem;

/**
 *
 * @author Tyrel
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class RentalApp {
    private List<User> users;
    private List<Property> properties;
    private List<Booking> bookings;
    private static final String USER_DATABASE_FILE = "Accounts.txt";

    public RentalApp() {
        users = new ArrayList<>();
        properties = new ArrayList<>();
        bookings = new ArrayList<>();
    }

    public void addUser(User user) {
        users.add(user);
        saveUsersToDatabase();
    }

    public void addProperty(Property property) {
        properties.add(property);
        // Additional logic for saving properties
    }

    public void addBooking(Booking booking) {
        bookings.add(booking);
        // Additional logic for saving bookings
    }

    // Additional methods for property search, availability indicator, rental agreements, and payments

    public void saveUsersToDatabase() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("E:\\NETBEANS PROJECT\\RENTSYSTEM\\src\\main\\java\\com\\mycompany\\rentsystem\\Accounts.txt"))) {
            for (User user : users) {
                writer.println(user.getUsername() + "," + user.getPassword() + "," + user.getRole());
            }
        } catch (IOException e) {
            System.out.println("Error saving users to database: " + e.getMessage());
        }
    }

    public void loadUsersFromDatabase() {
        try (BufferedReader reader = new BufferedReader(new FileReader("E:\\NETBEANS PROJECT\\RENTSYSTEM\\src\\main\\java\\com\\mycompany\\rentsystem\\Accounts.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userInfo = line.split(",");
                String username = userInfo[0];
                String password = userInfo[1];
                String role = userInfo[2];
                User user = new User(username, password, role);
                users.add(user);
            }
        } catch (IOException e) {
            System.out.println("Error loading users from database: " + e.getMessage());
        }
    }

    public List<User> getUsers() {
        return users;
    }

    public void createProperty(String name, String location, double price) {
        int id = properties.size() + 1;
        Property property = new Property(name, location, price);
        properties.add(property);
        // Additional logic for saving properties
    }

    // Placeholder methods, replace with your own implementation
    public List<Property> searchPropertiesByLocation(String location) {
        return new ArrayList<>();
    }

    public Property getPropertyById(int propertyId) {
        return null;
    }

    public Booking createBooking(User user, Property property) {
        return null;
    }

    public List<Property> getAvailableProperties() {
        List<Property> availableProperties = new ArrayList<>();
        for (Property property : properties) {
            if (property.isAvailable()) {
                availableProperties.add(property);
            }
        }
        return availableProperties;
    }

    public List<Property> getProperties() {
        return properties;
    }
}