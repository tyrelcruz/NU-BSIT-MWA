/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.rentsystem;

/**
 *
 * @author Tyrel
 */
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Scanner;

public class Main {
    private static final String PROPERTY_DATABASE_FILE = "Properties.txt";

    public static void main(String[] args) {
        RentalApp app = new RentalApp();
        app.loadUsersFromDatabase();
        loadPropertiesFromDatabase(app);

        // Additional code for user interaction and app functionality
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Rental App!");

        // User registration
        System.out.println("Do you have an account? (Y/N)");
        String hasAccount = scanner.nextLine();
        if (hasAccount.equalsIgnoreCase("N")) {
            System.out.println("Choose user role: (1) Admin or (2) Tenant");
            int roleChoice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            if (roleChoice == 1) {
                System.out.println("Admin registration:");
                System.out.println("Enter username:");
                String adminUsername = scanner.nextLine();
                System.out.println("Enter password:");
                String adminPassword = scanner.nextLine();
                User adminUser = new User(adminUsername, adminPassword, "Admin");
                app.addUser(adminUser);
                System.out.println("Admin account created successfully.");
            } else if (roleChoice == 2) {
                System.out.println("Tenant registration:");
                System.out.println("Enter username:");
                String tenantUsername = scanner.nextLine();
                System.out.println("Enter password:");
                String tenantPassword = scanner.nextLine();
                User tenantUser = new User(tenantUsername, tenantPassword, "Tenant");
                app.addUser(tenantUser);
                System.out.println("Tenant account created successfully.");
            } else {
                System.out.println("Invalid choice. Exiting the application.");
                System.exit(0);
            }
        }

        // Authentication code
        System.out.println("Please enter your username:");
        String username = scanner.nextLine();
        System.out.println("Please enter your password:");
        String password = scanner.nextLine();

        // Add your authentication logic here
        User authenticatedUser = null;
        for (User user : app.getUsers()) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                authenticatedUser = user;
                break;
            }
        }

        if (authenticatedUser == null) {
            System.out.println("Invalid username or password. Exiting the application.");
            System.exit(0);
        } else {
            System.out.println("Authentication successful. Welcome, " + authenticatedUser.getUsername() + "!");
        }

        // Admin functionality
        if (authenticatedUser.getRole().equals("Admin")) {
            System.out.println("Admin functionality:");
            System.out.println("1. Create Property");
            System.out.println("2. View Available Properties");
            System.out.println("3. Exit");
            System.out.println("Enter your choice:");

            int adminChoice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (adminChoice) {
                case 1:
                    createProperty(scanner, app);
                    break;
                case 2:
                    displayAvailableProperties(app);
                    break;
                case 3:
                    System.out.println("Exiting the application.");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Exiting the application.");
                    System.exit(0);
            }
        } else {
            // Tenant functionality
            System.out.println("Tenant functionality:");
            System.out.println("1. View Available Properties");
            System.out.println("2. Exit");
            System.out.println("Enter your choice:");

            int tenantChoice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (tenantChoice) {
                case 1:
                    displayAvailableProperties(app);

                    System.out.println("Enter the ID of the property you want to book:");
                    int propertyId = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character
                    Property selectedProperty = app.getPropertyById(propertyId);
                    if (selectedProperty != null && selectedProperty.isAvailable()) {
                        Booking newBooking = app.createBooking(authenticatedUser, selectedProperty);
                        app.addBooking(newBooking);
                        System.out.println("Booking request submitted successfully.");
                    } else {
                        System.out.println("Invalid property ID or property is not available.");
                    }
                    break;
                case 2:
                    System.out.println("Exiting the application.");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Exiting the application.");
                    System.exit(0);
            }
        }

        // Additional code for property search, booking requests, etc.
        // ...

        savePropertiesToDatabase(app);
    }

    private static void createProperty(Scanner scanner, RentalApp app) {
    while (true) {
        System.out.println("Enter property name:");
        String propertyName = scanner.nextLine();
        System.out.println("Enter property location:");
        String propertyLocation = scanner.nextLine();
        System.out.println("Enter property price:");
        double propertyPrice = scanner.nextDouble();
        scanner.nextLine(); // Consume the newline character

        Property newProperty = new Property(propertyName, propertyLocation, propertyPrice);
        app.addProperty(newProperty);
        System.out.println("Property created successfully.");

        savePropertiesToDatabase(app);
        
        System.out.println("Do you want to create another property? (Y/N)");
        String createAnother = scanner.nextLine();
        if (!createAnother.equalsIgnoreCase("Y")) {
            break;
        }
    }

    // Return to login after adding properties
    main(null);
}


    private static void displayAvailableProperties(RentalApp app) {
        System.out.println("Available properties:");
        List<Property> availableProperties = app.getAvailableProperties();
        if (availableProperties.isEmpty()) {
            System.out.println("No available properties at the moment.");
        } else {
            for (Property property : availableProperties) {
                System.out.println("ID: " + property.getId() + " - " + property.getName() + " - " + property.getLocation());
            }
        }
    }

    private static void savePropertiesToDatabase(RentalApp app) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("E:\\NETBEANS PROJECT\\RENTSYSTEM\\src\\main\\java\\com\\mycompany\\rentsystem\\Properties.txt"))) {
            List<Property> properties = app.getProperties();
            for (Property property : properties) {
                writer.write(property.getName() + "," + property.getLocation() + "," + property.getPrice());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error occurred while saving property database: " + e.getMessage());
        }
    }

    private static void loadPropertiesFromDatabase(RentalApp app) {
    try (BufferedReader reader = new BufferedReader(new FileReader("E:\\NETBEANS PROJECT\\RENTSYSTEM\\src\\main\\java\\com\\mycompany\\rentsystem\\Properties.txt"))) {
        String line;
        int nextId = 1;
        while ((line = reader.readLine()) != null) {
            String[] propertyData = line.split(",");
            if (propertyData.length == 3) {
                String propertyName = propertyData[0];
                String propertyLocation = propertyData[1];
                double propertyPrice = Double.parseDouble(propertyData[2]);

                Property property = new Property(propertyName, propertyLocation, propertyPrice);
                app.addProperty(property);
                nextId++;
            }
        }
    } catch (IOException e) {
        System.out.println("Error occurred while loading property database: " + e.getMessage());
    }
}

}